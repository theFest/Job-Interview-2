# Hamburger

## Description
The client requested us to create a hamburger and drink icon using only HTML and CSS (no images or SVG!)
You can find hamburger.png as a design reference.
So, you have to create a copy of the image using only HTML and CSS.

Note: We need a proof of concept. Don't waist too much time making it an exact copy!

## Definition of done
* There is only one HTML file
* There are no images linked within the file
* Hamburger and drink icon is created using HTML elements and CSS

## You will fail
* if you use any other tool than your brain and fingers
